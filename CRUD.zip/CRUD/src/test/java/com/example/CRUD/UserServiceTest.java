package com.example.CRUD;

import com.example.CRUD.model.User;
import com.example.CRUD.repository.UserRepository;
import com.example.CRUD.services.UserService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    @Test
    void shouldReturnAllUsers() {
        // Given: préparation des données d'entrée
        User user1 = new User(1L, "user1", "password1");
        User user2 = new User(2L, "user2", "password2");
        when(userRepository.findAll()).thenReturn(List.of(user1, user2));

        // When: action effectuée (récupération de tous les utilisateurs)
        List<User> actualUsers = userService.getAllUsers();

        // Then: comparaison entre les résultats attendus et actuels
        List<User> expectedUsers = List.of(user1, user2);
        assertThat(actualUsers).isEqualTo(expectedUsers); // Vérifie que les résultats actuels correspondent aux attentes
        verify(userRepository, times(1)).findAll();
    }

    @Test
    void shouldReturnUserById() {
        // Given: un utilisateur existant dans le référentiel
        User expectedUser = new User(1L, "user1", "password1");
        when(userRepository.findById(1L)).thenReturn(Optional.of(expectedUser));

        // When: récupération de l'utilisateur par son ID
        User actualUser = userService.getUserById(1L);

        // Then: comparaison entre le résultat attendu et actuel
        assertThat(actualUser).isEqualTo(expectedUser); // Vérifie que l'utilisateur retourné est celui attendu
        verify(userRepository, times(1)).findById(1L);
    }

    @Test
    void shouldCreateNewUser() {
        // Given: préparation de l'utilisateur à créer
        User newUser = new User(null, "newUser", "newPassword");
        User expectedUser = new User(1L, "newUser", "newPassword");
        when(userRepository.save(newUser)).thenReturn(expectedUser);

        // When: création du nouvel utilisateur
        User actualUser = userService.createUser(newUser);

        // Then: vérification du résultat actuel par rapport à l'attendu
        assertThat(actualUser).isEqualTo(expectedUser); // Vérifie que l'utilisateur créé correspond à l'utilisateur attendu
        verify(userRepository, times(1)).save(newUser);
    }

    @Test
    void shouldUpdateExistingUser() {
        // Given: un utilisateur existant et des détails mis à jour
        User existingUser = new User(1L, "oldUser", "oldPassword");
        User updatedDetails = new User(null, "updatedUser", "updatedPassword");
        User expectedUpdatedUser = new User(1L, "updatedUser", "updatedPassword");
        when(userRepository.findById(1L)).thenReturn(Optional.of(existingUser));
        when(userRepository.save(existingUser)).thenReturn(expectedUpdatedUser);

        // When: mise à jour de l'utilisateur
        User actualUpdatedUser = userService.updateUser(1L, updatedDetails);

        // Then: comparaison entre le résultat attendu et actuel
        assertThat(actualUpdatedUser).isEqualTo(expectedUpdatedUser); // Vérifie que les détails de l'utilisateur sont correctement mis à jour
        verify(userRepository, times(1)).findById(1L);
        verify(userRepository, times(1)).save(existingUser);
    }

    @Test
    void shouldDeleteUserById() {
        // Given: ID de l'utilisateur à supprimer
        Long userId = 1L;

        // When: suppression de l'utilisateur par son ID
        userService.deleteUser(userId);

        // Then: vérification que la suppression a été effectuée correctement
        verify(userRepository, times(1)).deleteById(userId); // Vérifie que la méthode de suppression a été appelée avec l'ID correct
    }
}
